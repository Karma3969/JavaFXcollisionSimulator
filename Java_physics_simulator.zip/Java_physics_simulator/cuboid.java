public class cuboid extends moveableobject{
}
